package com.meetingandmail;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.*; 
import javax.mail.*; 
import javax.mail.internet.*; 
import javax.activation.*; 
import javax.mail.Session; 
import javax.mail.Transport; 

/**
 * Servlet implementation class MeetingandMail
 */
@WebServlet("/MeetingandMail")
public class MeetingandMail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MeetingandMail() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String title = request.getParameter("title");
		String description = request.getParameter("description");
		String link = request.getParameter("link");
		String date = request.getParameter("date").toString();
		String starttime = request.getParameter("starttime").toString();
		String endtime = request.getParameter("endtime").toString();
		
		String sql="insert into meeting (title,description,link,date,starttime,endtime) values(?,?,?,?,?,?)";
		String url ="jdbc:mysql://localhost:3306/Agile_Meeting";
		String username="root";
		String password="Jaggufriend";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url,username,password);
			PreparedStatement st = con.prepareStatement(sql);
			st.setString(1, title);
			st.setString(2, description);
			st.setString(3, link);
			st.setString(4, date);
			st.setString(5, starttime);
			st.setString(6, endtime);
			st.execute();
			System.out.println("Meeting created Success");
			
			// email ID of Recipient. 
		      String recipient = "2k17ece073@kiot.ac.in"; 
		  
		      // email ID of  Sender. 
		      String sender = "vsoft.meetings@outlook.com"; 
		  
		      // using host as localhost 
		      String host = "localhost"; 
		  
		      // Getting system properties 
		      Properties properties = System.getProperties(); 
		  
		      // Setting up mail server 
		      properties.setProperty("mail.smtp.host", host); 
		      
		      //user name and passsword
		      properties.setProperty("mail.user", "vsoft.meetings@outlook.com");
		      properties.setProperty("mail.password", "VirtusaProject");
		  
		      // creating session object to get properties 
		      Session session = Session.getDefaultInstance(properties); 
		  
		      try 
		      { 
		         // MimeMessage object. 
		         MimeMessage message = new MimeMessage(session); 
		  
		         // Set From Field: adding senders email to from field. 
		         message.setFrom(new InternetAddress(sender)); 
		  
		         // Set To Field: adding recipient's email to from field. 
		         message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient)); 
		  
		         // Set Subject: subject of the email 
		         message.setSubject("This is Suject"); 
		  
		         // set body of the email. 
		         message.setText("This is a test mail"); 
		  
		         // Send email. 
		         Transport.send(message); 
		         System.out.println("Mail successfully sent"); 
		      } 
		      catch (MessagingException e)  
		      { 
		         e.printStackTrace(); 
		      } 
			
			
		}
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
	}

}
